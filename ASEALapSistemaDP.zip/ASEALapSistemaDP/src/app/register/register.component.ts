import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_services/auth.service';
import {  ConfirmPasswordValidator } from '../_helpers/confirmpasswordvalidator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form: any = {
    username: null,
    email: null,
    password: null,
    confirm_password: null,
    termsConditions: false,
  };
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  } 
  onSubmit(): void 
  {
    const { username, email, password,confirm_password,termsConditions } = this.form;

    if(termsConditions)
    //if ( password.value === confirm_password.value )
    {

      console.log(password.value,confirm_password.value, 'Válido',termsConditions ,'--', termsConditions.value  );
      
      this.authService.register(username, email, password).subscribe(
        data => {
          console.log(data);
          this.isSuccessful = true;
          this.isSignUpFailed = false;
        },
        err => {
          this.errorMessage = err.error.message;
          this.isSignUpFailed = true;
        }
      );  
    }
    else
    {
      //this.errorMessage = err.error.message;
      console.log(password,confirm_password, 'Inválido','Debe aceptar los terminos y condiciones');
      this.isSignUpFailed = true;
    } 
  }
}
